SELECT DISTINCT FirstName,SalaryPerDay,Name,JobDescription
FROM (SELECT A.PID, Name,JobDescription,EID FROM ProjectConstructorEmployee A JOIN Project B WHERE A.PID=B.PID ) AS PCE JOIN
(SELECT Employee.EID,FirstName,SalaryPerDay FROM ConstructorEmployee JOIN Employee ON ConstructorEmployee.EID=Employee.EID) AS PE
WHERE PCE.EID=PE.EID

