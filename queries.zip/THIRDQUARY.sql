SELECT Name, count(NID) AS 'APARNUM'
FROM (
SELECT  Neighborhood.NID, Neighborhood.Name,StreetName,Number,Door
 FROM (Neighborhood JOIN (SELECT DISTINCT StreetName, Number ,NID,Door FROM Apartment) AS APAR )
 WHERE Neighborhood.NID= APAR.NID)
 GROUP by NID
 ORDER BY APARNUM DESC