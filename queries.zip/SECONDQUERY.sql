SELECT EID,NULL AS Department,Name
FROM(SELECT EID, PID,max(EndWorkingDate) AS MAXDATE
FROM ProjectConstructorEmployee GROUP BY EID) AS A 
JOIN Project AS B
WHERE A.PID=B.PID
UNION 
SELECT EID,Department,NULL AS Name FROM OfficialEmployee 