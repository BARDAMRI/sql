SELECT R.FirstName,R.LastName, A.*
FROM Apartment AS A LEFT JOIN Resident AS R ON A.StreetName=R.StreetName AND A.Door=R.Door AND A.Number=R.Number
