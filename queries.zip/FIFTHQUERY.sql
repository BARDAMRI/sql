SELECT *
FROM ParkingArea
WHERE MaxPricePerDay=(SELECT MIN (MaxPricePerDay) AS MINIMUM FROM ParkingArea)