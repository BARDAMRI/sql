CREATE VIEW r_ngbrhd as
SELECT * 
FROM Neighborhood 
WHERE Name like 'R%'